package com.example.covid19.model

